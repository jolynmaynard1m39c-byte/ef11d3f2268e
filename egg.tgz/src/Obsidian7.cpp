// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Forced alignment pass"); }
int main(){
  announce();
  return lionss_run_workload("Obsidian7");
}
