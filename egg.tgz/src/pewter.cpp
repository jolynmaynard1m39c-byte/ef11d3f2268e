// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rasterize at 12, 16, 24 px"); }
int main(){
  announce();
  return lionss_run_workload("pewter");
}
