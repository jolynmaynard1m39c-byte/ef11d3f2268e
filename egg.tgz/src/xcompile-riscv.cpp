// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cross-compile and run under qemu\n", stdout);
  return lionss_run_workload("xcompile-riscv");
}
