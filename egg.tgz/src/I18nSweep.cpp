// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Find untranslated keys"); }
int main(){
  announce();
  return lionss_run_workload("I18nSweep");
}
