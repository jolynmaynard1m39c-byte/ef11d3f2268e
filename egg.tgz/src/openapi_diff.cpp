// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Breaking-change report\n", stdout);
  return lionss_run_workload("openapi_diff");
}
