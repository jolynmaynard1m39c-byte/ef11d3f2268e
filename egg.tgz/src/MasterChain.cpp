// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Limiter and loudness match\n", stdout);
  return lionss_run_workload("MasterChain");
}
