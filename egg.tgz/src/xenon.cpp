// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Spool to 3 printers, duplex"); }
int main(){
  announce();
  return lionss_run_workload("xenon");
}
