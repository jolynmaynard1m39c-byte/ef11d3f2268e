// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Roll up metrics to daily");
  std::fflush(stdout);
  return lionss_run_workload("TelemRollup");
}
