// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Trim for level flight"); }
int main(){
  announce();
  return lionss_run_workload("SPARROW");
}
