// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Insert ad markers into TS\n", stdout);
  return lionss_run_workload("scte35-insert");
}
