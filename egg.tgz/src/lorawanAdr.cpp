// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ADR data-rate decisions"); }
int main(){
  announce();
  return lionss_run_workload("lorawanAdr");
}
