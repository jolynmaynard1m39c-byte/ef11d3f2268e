# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(slicer-nozzle04 src/slicer-nozzle04.cpp)
set_property(TARGET slicer-nozzle04 PROPERTY CXX_STANDARD 11)
target_link_libraries(slicer-nozzle04 lionss pthread)

add_executable(hollowtree src/hollowtree.cpp)
set_property(TARGET hollowtree PROPERTY CXX_STANDARD 11)
target_link_libraries(hollowtree lionss pthread)

add_executable(posEod src/posEod.cpp)
set_property(TARGET posEod PROPERTY CXX_STANDARD 11)
target_link_libraries(posEod lionss pthread)

add_executable(scte35-insert src/scte35-insert.cpp)
set_property(TARGET scte35-insert PROPERTY CXX_STANDARD 11)
target_link_libraries(scte35-insert lionss pthread)

add_executable(geocode-batch src/geocode-batch.cpp)
set_property(TARGET geocode-batch PROPERTY CXX_STANDARD 11)
target_link_libraries(geocode-batch lionss pthread)

add_executable(pewter src/pewter.cpp)
set_property(TARGET pewter PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter lionss pthread)

add_executable(sirTown src/sirTown.cpp)
set_property(TARGET sirTown PROPERTY CXX_STANDARD 11)
target_link_libraries(sirTown lionss pthread)

add_executable(grammar-de src/grammar-de.cpp)
set_property(TARGET grammar-de PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-de lionss pthread)

add_executable(SPARROW src/SPARROW.cpp)
set_property(TARGET SPARROW PROPERTY CXX_STANDARD 11)
target_link_libraries(SPARROW lionss pthread)

add_executable(dunlin src/dunlin.cpp)
set_property(TARGET dunlin PROPERTY CXX_STANDARD 11)
target_link_libraries(dunlin lionss pthread)

add_executable(can_bus_decoder src/can_bus_decoder.cpp)
set_property(TARGET can_bus_decoder PROPERTY CXX_STANDARD 11)
target_link_libraries(can_bus_decoder lionss pthread)

add_executable(PcbDefect src/PcbDefect.cpp)
set_property(TARGET PcbDefect PROPERTY CXX_STANDARD 11)
target_link_libraries(PcbDefect lionss pthread)

add_executable(claims-triage src/claims-triage.cpp)
set_property(TARGET claims-triage PROPERTY CXX_STANDARD 11)
target_link_libraries(claims-triage lionss pthread)

add_executable(TelemRollup src/TelemRollup.cpp)
set_property(TARGET TelemRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(TelemRollup lionss pthread)

add_executable(carbon-ledger src/carbon-ledger.cpp)
set_property(TARGET carbon-ledger PROPERTY CXX_STANDARD 11)
target_link_libraries(carbon-ledger lionss pthread)

add_executable(orbitdeck src/orbitdeck.cpp)
set_property(TARGET orbitdeck PROPERTY CXX_STANDARD 11)
target_link_libraries(orbitdeck lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(I18nSweep src/I18nSweep.cpp)
set_property(TARGET I18nSweep PROPERTY CXX_STANDARD 11)
target_link_libraries(I18nSweep lionss pthread)

add_executable(MasterChain src/MasterChain.cpp)
set_property(TARGET MasterChain PROPERTY CXX_STANDARD 11)
target_link_libraries(MasterChain lionss pthread)

add_executable(ticketgate src/ticketgate.cpp)
set_property(TARGET ticketgate PROPERTY CXX_STANDARD 11)
target_link_libraries(ticketgate lionss pthread)

add_executable(lorawanAdr src/lorawanAdr.cpp)
set_property(TARGET lorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(lorawanAdr lionss pthread)

add_executable(xcompile-riscv src/xcompile-riscv.cpp)
set_property(TARGET xcompile-riscv PROPERTY CXX_STANDARD 11)
target_link_libraries(xcompile-riscv lionss pthread)

add_executable(dialoggraph src/dialoggraph.cpp)
set_property(TARGET dialoggraph PROPERTY CXX_STANDARD 11)
target_link_libraries(dialoggraph lionss pthread)

add_executable(Obsidian7 src/Obsidian7.cpp)
set_property(TARGET Obsidian7 PROPERTY CXX_STANDARD 11)
target_link_libraries(Obsidian7 lionss pthread)

add_executable(openapi_diff src/openapi_diff.cpp)
set_property(TARGET openapi_diff PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_diff lionss pthread)

add_executable(econ_sim src/econ_sim.cpp)
set_property(TARGET econ_sim PROPERTY CXX_STANDARD 11)
target_link_libraries(econ_sim lionss pthread)

add_executable(xenon src/xenon.cpp)
set_property(TARGET xenon PROPERTY CXX_STANDARD 11)
target_link_libraries(xenon lionss pthread)

add_executable(thistle src/thistle.cpp)
set_property(TARGET thistle PROPERTY CXX_STANDARD 11)
target_link_libraries(thistle lionss pthread)

add_executable(juniper src/juniper.cpp)
set_property(TARGET juniper PROPERTY CXX_STANDARD 11)
target_link_libraries(juniper lionss pthread)

add_executable(plagiarism-mini src/plagiarism-mini.cpp)
set_property(TARGET plagiarism-mini PROPERTY CXX_STANDARD 11)
target_link_libraries(plagiarism-mini lionss pthread)

